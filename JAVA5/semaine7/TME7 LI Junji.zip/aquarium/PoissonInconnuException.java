/*
LI Junji 28610187
*/
public class PoissonInconnuException extends Exception{

    /**
     *
     */
    private static final long serialVersionUID = 3437554213286703001L;
}
