public abstract class AnimalSansPattes extends Animal{
    
    protected AnimalSansPattes(String nom, int age){
        super(nom, age);
    }

    protected AnimalSansPattes(String nom){
        super(nom);
    }
}
