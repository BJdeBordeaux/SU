public abstract class AnimalAPattes extends Animal{
    int nbPattes;

    protected AnimalAPattes(String nom, int age){
        super(nom, age);
    }

    protected AnimalAPattes(String nom){
        super(nom);
    }
}