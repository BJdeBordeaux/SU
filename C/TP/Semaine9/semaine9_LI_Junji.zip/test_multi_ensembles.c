#include <stdio.h>
#include <stdlib.h>
#include "multi_ensembles.h"

int main() {
  element_t *ens1 =  Creation_ensemble(1);
  Affiche_ensemble(ens1);
  printf("\n");
  ens1 = Ajout_ensemble_trie(ens1, 0, 3);
  Affiche_ensemble(ens1);
  return 0;
}