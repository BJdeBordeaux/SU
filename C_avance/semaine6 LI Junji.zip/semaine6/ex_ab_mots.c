#include <stdlib.h>
#include <stdio.h>
#include "arbre_binaire.h"
#include "fonctions_string.h"

int main(void) {

  /* a completer. Exercice 4, question 2 */

  return 0;
}
