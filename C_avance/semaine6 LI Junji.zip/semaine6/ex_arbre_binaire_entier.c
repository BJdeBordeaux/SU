#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "arbre_binaire.h"

int main(void) {
  srand(time(NULL));
  int n=10;
  int i;

  PArbreBinaire pab=creer_arbre(1,
  
  for (i=0;i<n;i++) {
    
  }
  return 1;
}
