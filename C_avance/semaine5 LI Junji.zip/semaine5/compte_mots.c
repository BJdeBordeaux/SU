#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "devel.h"
#include "liste.h"
#include "fonctions_2entiers.h"
#include "fonctions_string.h"

void compte(void *data, void *optarg) {
  /* a completer. Exercice 6, question 2 */
}

int main(void) {

  /* a completer. Exercice 6, question 2 */
  
  return 0;
}
