# Rapport de TME1
### par LI Junji && Mohamed BABAALI

* Les codes demandés sont dans les autres fichiers.
* Question 2.9
    - La valeur du champs ru_maxrss augmente après on appelle InitTab.
    - Si on initialise un tableau, alors la mémoire que le programme occupe augmente. Donc elle est allouée effectivement quand la tableau est initialisé.