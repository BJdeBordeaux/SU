#ifndef _FONCTIONS_H_
#define _FONCTIONS_H_
void lance_commande(char *commande);
void lance_commande2(char *commande);
#endif