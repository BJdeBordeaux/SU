int main()
{
    for (unsigned long i = 0; i < (5000000000); i++){}
    
    return 0;
}
